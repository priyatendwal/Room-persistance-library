package com.project.room.models;

public class Note {

}
